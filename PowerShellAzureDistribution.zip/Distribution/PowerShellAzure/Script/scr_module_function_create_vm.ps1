﻿<#
   Author:  Bryan Cafferky  2017-04-13

   Script that uses function New-udfCompleteVMDemo in module umd_azure
   to create an Azure VM with all required related resources.

#>

Import-Module umd_azure -Force -Verbose

New-udfCompleteVMDemo -resourceprefix "demo10" -Verbose