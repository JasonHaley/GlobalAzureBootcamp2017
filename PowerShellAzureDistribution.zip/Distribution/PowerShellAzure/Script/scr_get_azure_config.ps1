﻿Import-Module umd_azure -Force

$Myconfig = Get-udfConfig

$Myconfig.emailaccount

Save-UdfEncryptedCredential