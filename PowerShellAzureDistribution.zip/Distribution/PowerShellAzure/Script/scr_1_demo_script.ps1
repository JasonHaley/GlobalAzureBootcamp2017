﻿## Create an array named $myArray that contains the ten numeric (int) values:1,2,3,4,5,6,7,8,9,10; 

$myArray = 1,2,3,4,5,6,7,8,9,10; 

[int] $sum = 0; 

foreach ($val in $myArray) 
{
   write-host ("Index with value:$val"); 
   $sum = $sum + $val; 
} 

write-host ("The sum is: $sum");
