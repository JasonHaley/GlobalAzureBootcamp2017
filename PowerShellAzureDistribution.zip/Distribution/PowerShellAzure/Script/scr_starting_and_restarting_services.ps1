﻿Add-AzureRmAccount

# Get-AzureVM does not work with Resource Manager...
Get-AzureRmVM   #  Get's list of VMs and properties...

Get-AzureRMVM | Select-Object -Property ServiceName  # None

Get-AzureRmVM -Name "Demo" -ResourceGroupName "Demo"  # More details...

Start-AzureRmVM -Name "Demo" -ResourceGroupName "Demo"

Get-AzureRmVM  | Start-AzureRmVM #  Cannot cancel PowerShell command once started.

<#
      Removing Resources....
#>

Remove-AzureRmResource -ResourceName mystoragename -ResourceType Microsoft.Storage/storageAccounts -ResourceGroupName TestRG1

Remove-AzureRmResourceGroup -Name TestRG1



