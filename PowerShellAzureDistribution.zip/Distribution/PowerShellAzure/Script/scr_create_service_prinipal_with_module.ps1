﻿Import-Module umd_azure -Force

# Add-AzureRmAccount

Clear-Host

$ApplicationDisplayName = "demobpc12app"
$ResourceGroupName = 'demo3RG'
 
#  Returns the Application object...
$myapp = New-udfAzureServicePrincipal -ApplicationDisplayName $ApplicationDisplayName `
 -Password ('somesstuff?' + (Get-Random).ToString()) -Verbose  


# Log in with the Service Principal...
cls
New-udfAzureRmVMLoginServicePrincipal -ApplicationDisplayName $ApplicationDisplayName -Verbose    
 





<#
$myapp.ApplicationID

Add-AzureRmAccount -Credential $creds -ServicePrincipal -TenantId $tenantid

Stop-AzureRmVM -Name 'Demo3VM' -ResourceGroupName "Demo3RG" -Force

#>
