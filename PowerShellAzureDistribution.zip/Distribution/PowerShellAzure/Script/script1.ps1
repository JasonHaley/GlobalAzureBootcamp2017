﻿function stayinmem ([string] $var1)
{

 Write-Host "$var1"
  
}

"Script 1 executed..."