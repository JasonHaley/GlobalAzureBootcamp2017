﻿Add-AzureRmAccount

Get-AzureRmBillingInvoice

Get-AzureRmSubscription

Select-AzureRmSubscription -SubscriptionName "My Demos"

Get-AzureRmContext

Get-AzureRmVM | Format-Table Name,ResourceGroupName,Location -AutoSize

Get-AzureRmResource -ResourceName mystoragename -ResourceGroupName TestRG1

Find-AzureRmResource -ResourceNameContains mystoragename


