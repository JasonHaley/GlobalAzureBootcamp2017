﻿function runonce ([string] $var1)
{

 Write-Host "$var1"
  
}

"Script 2 executed..."
runonce "Script2"