﻿<#
    Author: Bryan Cafferky   2017-04-15

    Name: scr_using_service_principal.ps1

    Logs in with Service Principal and does some
    Azure stuff.

#>

Import-Module umd_azure -Force

Clear-Host

#  Now let's do some Azure stuff...

# Fun with VMs...

Get-AzureRmVM

Get-AzureRmResourceGroup 

Get-AzureRmSubscription


#  Notice the VM Status is not shown and is actually not easy to get to.
#  Each VM has a Status array column and we have to use a work around to get
#  to it.

$targetvm = 'demo3vm'
$targetrg = 'DEMO3RG'

# Run these lines together to get a single VM and its Status...
Get-Azurermvm -Name $targetvm -ResourceGroupName $targetrg
(Get-Azurermvm -Name $targetvm -ResourceGroupName $targetrg -Status).Statuses | Select-Object -Property DisplayStatus

Stop-AzureRmVM -Name $targetvm -ResourceGroupName $targetrg -Force

#  Run these lines together to get a single VM and its Status...
Get-Azurermvm -Name $targetvm -ResourceGroupName $targetrg
(Get-Azurermvm -Name $targetvm -ResourceGroupName $targetrg -Status).Statuses | Select-Object -Property DisplayStatus

# Let's Start it again...
Start-AzureRmVM -Name $targetvm -ResourceGroupName $targetrg

Get-Azurermvm -Name $targetvm -ResourceGroupName $targetrg
(Get-Azurermvm -Name $targetvm -ResourceGroupName $targetrg -Status).Statuses | Select-Object -Property DisplayStatus

# Restart a VM...
Restart-AzureRmVM -Name $targetvm -ResourceGroupName $targetrg 
